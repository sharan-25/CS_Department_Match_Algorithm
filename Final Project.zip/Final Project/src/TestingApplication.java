import java.util.Arrays;

import pa3.ds.project.*;

public class TestingApplication {
public static void main(String[] args) {
		
		//1 - using Array
		// Create a CircularQueueArray of integers
        Queue<Integer> queue = new Queue<>();
        System.out.println("CrcularQueue using Array---------");
        // Enqueue elements
        queue.enqueue(10);
        queue.enqueue(5);
        queue.enqueue(20);
        queue.enqueue(15);

        // Display the queue
        System.out.println("Queue after enqueue:");
        queue.displayAllElements(); 

        // Dequeue an element
        
        queue.dequeue();
        

        // Display the queue after dequeue
        System.out.println("Queue after dequeue:");
        queue.displayAllElements(); 

        // Get the size of the queue
        int size = queue.getSize();
        System.out.println("Size of the queue: " + size); 

        // Search for an element
         queue.search(20);
        

        // Create a CircularQueueArray from a list
        Queue<Integer> queueFromList = new Queue<>(Arrays.asList(5, 15, 25));
        System.out.println("Queue from list:");
        queueFromList.displayAllElements(); 
        
     
        //2 -- using LinkedList
        QueueLinkedList<Integer> queue2 = new QueueLinkedList<>();
        System.out.println("CrcularQueue using LinkedList---------");
        // Enqueue elements
        queue2.enqueue(20);
        queue2.enqueue(54);
        queue2.enqueue(25);
        queue2.enqueue(15);
        // Display the queue
        System.out.println("Queue after enqueue:");
        queue2.displayAllElements(); 
        
        // Dequeue an element
        
        queue2.dequeue();
        

        // Display the queue after dequeue
        System.out.println("Queue after dequeue:");
        queue2.displayAllElements(); 

        // Get the size of the queue
        int size1 = queue2.getSize();
        System.out.println("Size of the queue: " + size1); 
        
        //3. Implement Priority Queue using LinkedList
        System.out.println("Priority Queue using LinkedList.............");
        // Create a priority queue of integers
        PriorityQueueLinkedList<Integer> priorityQueue1 = new PriorityQueueLinkedList<>();

        // Enqueue some elements into the priority queue
        priorityQueue1.enqueue(10);
        priorityQueue1.enqueue(5);
        priorityQueue1.enqueue(20);
        priorityQueue1.enqueue(15);

        // Display all elements in the priority queue
        System.out.println("Elements in the priority queue:");
        priorityQueue1.displayAllElements();

        // Display the element if found
        priorityQueue1.displayElement(20);

        // Display all elements with higher priority than 10
        System.out.println("Elements with higher priority than 10:");
        priorityQueue1.displayHigherElements(10);

        // Display all elements with lower priority than 15
        System.out.println("Elements with lower priority than 15:");
        priorityQueue1.displayLowerElements(15);
        
        
        //4. Implement Priority Queue using Array
        System.out.println("Priority Queue using Array...............");
        // Create a PriorityQueue object of type Integer
        PriorityQueue<Integer> priorityQueue = new PriorityQueue<>();

        // Enqueue some elements into the priority queue
        priorityQueue.enqueue(10);
        priorityQueue.enqueue(5);
        priorityQueue.enqueue(20);
        priorityQueue.enqueue(15);

        // Display all elements in the priority queue
        System.out.println("All Elements in the priority queue:");
        priorityQueue.displayAllElements();

        // Display an element if found in the priority queue
        priorityQueue.displayElement(10);

        // Display all elements with Higher priority than a given object
        System.out.println("Elements with higher priority than 12:");
        priorityQueue.displayHigherElements(12);

        // Display all elements with Lower priority than a given object
        System.out.println("Elements with lower priority than 15:");
        priorityQueue.displayLowerElements(15);
       
        
        
}
}

package pa3.model.project;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Represents a department in an educational institution.
 */
public class Department {

    // Class fields
    private Map<String, Course> courseMap;  // Represents a mapping of course IDs to Course objects
    private List<Professor> listOfProfs;     // List of professors in the department

    // Getter and setter methods

    /**
     * Retrieves the mapping of course IDs to Course objects.
     *
     * @return The mapping of course IDs to Course objects.
     */
    public Map<String, Course> getCourseMap() {
        return courseMap;
    }

    /**
     * Sets the mapping of course IDs to Course objects.
     *
     * @param courseMap The mapping of course IDs to Course objects.
     */
    public void setCourseMap(Map<String, Course> courseMap) {
        this.courseMap = courseMap;
    }

    /**
     * Retrieves the list of professors in the department.
     *
     * @return The list of professors in the department.
     */
    public List<Professor> getListOfProfs() {
        return listOfProfs;
    }

    /**
     * Sets the list of professors in the department.--------------------------
     *
     * @param listOfProfs The list of professors in the department.
     */
    public void setListOfProfs(List<Professor> listOfProfs) {
        this.listOfProfs = listOfProfs;
    }

    // Partially Parameterized Constructor

    /**
     * Constructs a department with the specified list of professors.
     *
     * @param listOfProfs The list of professors in the department.
     */
    public Department(List<Professor> listOfProfs) {
        this.courseMap = new HashMap<>();
        this.listOfProfs = listOfProfs;
    }

    /**
     * Adds a course to the department.
     *
     * @param course The course to be added.
     */
    public void addCourse(Course course) {
        this.courseMap.put(course.getId(), course);
    }
}

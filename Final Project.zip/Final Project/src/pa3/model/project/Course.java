package pa3.model.project;

/**
 * Represents a course in the educational system.
 */
public class Course {

    // Class fields
    private String id;               // The unique identifier of the course
    private String title;            // The title of the course
    private String discipline;       // The discipline to which the course belongs
    private int numberOfHours;       // The number of hours allocated to the course
    private int numOfGroups;         // The number of groups for the course

    // Getter and setter methods

    /**
     * Retrieves the unique identifier of the course.
     *
     * @return The unique identifier of the course.
     */
    public String getId() {
        return id;
    }

    /**
     * Sets the unique identifier of the course.
     *
     * @param id The unique identifier of the course.
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Retrieves the title of the course.
     *
     * @return The title of the course.
     */
    public String getTitle() {
        return title;
    }

    /**
     * Sets the title of the course.
     *
     * @param title The title of the course.
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * Retrieves the discipline to which the course belongs.
     *
     * @return The discipline of the course.
     */
    public String getDiscipline() {
        return discipline;
    }

    /**
     * Sets the discipline to which the course belongs.
     *
     * @param discipline The discipline of the course.
     */
    public void setDiscipline(String discipline) {
        this.discipline = discipline;
    }

    /**
     * Retrieves the number of hours allocated to the course.
     *
     * @return The number of hours allocated to the course.
     */
    public int getNumberOfHours() {
        return numberOfHours;
    }

    /**
     * Sets the number of hours allocated to the course.
     *
     * @param numberOfHours The number of hours allocated to the course.
     */
    public void setNumberOfHours(int numberOfHours) {
        this.numberOfHours = numberOfHours;
    }

    /**
     * Retrieves the number of groups for the course.
     *
     * @return The number of groups for the course.
     */
    public int getNumOfGroups() {
        return numOfGroups;
    }

    /**
     * Sets the number of groups for the course.
     *
     * @param numOfGroups The number of groups for the course.
     */
    public void setNumOfGroups(int numOfGroups) {
        this.numOfGroups = numOfGroups;
    }

    // Fully Parameterized Constructor

    /**
     * Constructs a course with the specified details.
     *
     * @param id            The unique identifier of the course.
     * @param title         The title of the course.
     * @param discipline    The discipline to which the course belongs.
     * @param numberOfHours The number of hours allocated to the course.
     * @param numOfGroups   The number of groups for the course.
     */
    public Course(String id, String title, String discipline, int numberOfHours, int numOfGroups) {
        this.id = id;
        this.title = title;
        this.discipline = discipline;
        this.numberOfHours = numberOfHours;
        this.numOfGroups = numOfGroups;
    }

    // Copy Constructor

    /**
     * Constructs a new course by copying the values from an existing course object.
     *
     * @param course The course to be copied.
     */
    public Course(Course course) {
        this.id = course.id;
        this.title = course.title;
        this.discipline = course.discipline;
        this.numberOfHours = course.numberOfHours;
        this.numOfGroups = course.numOfGroups;
    }

    /**
     * Returns a string representation of the course.
     *
     * @return A string representation of the course, including its id, title, discipline, number of hours, and number of groups.
     */
    @Override
    public String toString() {
        return "Course [id=" + id + ", title=" + title + ", discipline=" + discipline + ", numberOfHours="
                + numberOfHours + ", numOfGroups=" + numOfGroups + "]";
    }
}

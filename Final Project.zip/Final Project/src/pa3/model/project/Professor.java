package pa3.model.project;


import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * Represents a Professor in a university system.
 * This class provides attributes and methods to manage professor-related information,
 * such as ID, name, seniority level, hiring date, set of disciplines, and list of affected courses.
 */
public class Professor implements Comparable<Professor> {

    // Class fields
    private int id; // The unique identifier for the professor
    private String name; // The name of the professor
    private double seniorityLevel; // The seniority level of the professor
    private Date hiringDate; // The date when the professor was hired
    private Set<String> setOfDisciplines; // The set of disciplines the professor is specialized in
    private List<Course> listOfAffectedCourses; // The list of courses affected by the professor

    /**
     * Constructs a new Professor object with specified attributes.
     * 
     * @param id              The unique identifier for the professor.
     * @param name            The name of the professor.
     * @param seniorityLevel The seniority level of the professor.
     * @param hiringDate      The date when the professor was hired.
     */
    public Professor(int id, String name, double seniorityLevel, Date hiringDate) {
        this.id = id;
        this.name = name;
        this.seniorityLevel = seniorityLevel;
        this.hiringDate = hiringDate;
        this.setOfDisciplines = new HashSet<>(); // Initialize the set of disciplines
        this.listOfAffectedCourses = new ArrayList<>(); // Initialize the list of affected courses
    }

    /**
     * Compares this professor with another professor for order.
     * 
     * @param o The professor to be compared.
     * @return A negative integer, zero, or a positive integer as this professor is less than, equal to, or greater
     *         than the specified professor, based on seniority level and hiring date.
     */
    @Override
    public int compareTo(Professor o) {
        // Compare seniority level
        if (this.seniorityLevel != o.seniorityLevel) {
            return Double.compare(this.seniorityLevel, o.seniorityLevel);
        } else {
            // If seniority levels are equal, compare based on hiring date
            return this.hiringDate.compareTo(o.hiringDate);
        }
    }

    /**
     * Retrieves the ID of the professor.
     * 
     * @return The ID of the professor.
     */
    public int getId() {
        return id;
    }

    /**
     * Sets the ID of the professor.
     * 
     * @param id The ID to be set for the professor.
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Retrieves the name of the professor.
     * 
     * @return The name of the professor.
     */
    public String getName() {
        return name;
    }

    /**
     * Sets the name of the professor.
     * 
     * @param name The name to be set for the professor.
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Retrieves the seniority level of the professor.
     * 
     * @return The seniority level of the professor.
     */
    public double getSeniorityLevel() {
        return seniorityLevel;
    }

    /**
     * Sets the seniority level of the professor.
     * 
     * @param seniorityLevel The seniority level to be set for the professor.
     */
    public void setSeniorityLevel(double seniorityLevel) {
        this.seniorityLevel = seniorityLevel;
    }

    /**
     * Retrieves the hiring date of the professor.
     * 
     * @return The hiring date of the professor.
     */
    public Date getHiringDate() {
        return hiringDate;
    }

    /**
     * Sets the hiring date of the professor.
     * 
     * @param hiringDate The hiring date to be set for the professor.
     */
    public void setHiringDate(Date hiringDate) {
        this.hiringDate = hiringDate;
    }

    /**
     * Retrieves the set of disciplines the professor is specialized in.
     * 
     * @return The set of disciplines.
     */
    public Set<String> getSetOfDisciplines() {
        return setOfDisciplines;
    }

    /**
     * Sets the set of disciplines the professor is specialized in.
     * 
     * @param setOfDisciplines The set of disciplines to be set for the professor.
     */
    public void setSetOfDisciplines(Set<String> setOfDisciplines) {
        this.setOfDisciplines = setOfDisciplines;
    }

    /**
     * Retrieves the list of courses affected by the professor.
     * 
     * @return The list of affected courses.
     */
    public List<Course> getListOfAffectedCourses() {
        return listOfAffectedCourses;
    }

    /**
     * Sets the list of courses affected by the professor.
     * 
     * @param listOfAffectedCourses The list of affected courses to be set for the professor.
     */
    public void setListOfAffectedCourses(List<Course> listOfAffectedCourses) {
        this.listOfAffectedCourses = listOfAffectedCourses;
    }

    /**
     * Returns a string representation of the Professor object.
     * 
     * @return A string representation of the Professor object, including its ID, name, seniority level, hiring date,
     *         set of disciplines, and list of affected courses.
     */
    @Override
    public String toString() {
        return "Professor [id=" + id + ", name=" + name + ", seniorityLevel=" + seniorityLevel + ", hiringDate="
                + hiringDate + ", setOfDisciplines=" + setOfDisciplines + ", listOfAffectedCourses="
                + listOfAffectedCourses + "]";
    }
}

package pa3.ds.project;

import java.util.List;

/**
 * Represents a circular queue implementation using an array.
 *
 * @param <T> The type of elements stored in the queue.
 */
public class Queue<T> {
    private T[] CircularQArray;
    private int front = -1; // Variable to track the front of the queue
    private int rear = -1;  // Variable to track the rear of the queue
    private int size = 0;   // Size of the queue

    
    //Getter- Setter
    public T[] getCircularQArray() {
        return CircularQArray;
    }

    public void setCircularQArray(T[] circularQArray) {
        CircularQArray = circularQArray;
    }

    public int getFront() {
        return front;
    }

    public void setFront(int front) {
        this.front = front;
    }

    public int getRear() {
        return rear;
    }

    public void setRear(int rear) {
        this.rear = rear;
    }

    public void setSize(int size) {
        this.size = size;
    }

    /**
     * Default constructor, creates an array of length 20.
     */
    public Queue() {
        CircularQArray = (T[]) new Object[20];
        this.rear = this.front = -1;
    }

    /**
     * Constructor to create a queue from a list of objects,
     * such that the size of the queue is 2x the number of elements received.
     *
     * @param list The list of elements to initialize the queue with.
     */
    public Queue(List<T> list) {
        int initialSize = list.size() * 2; // Calculate initial size based on list size
        CircularQArray = (T[]) new Object[initialSize]; // Initialize the circular queue array with initial size

        for (T item : list) {
            enqueue(item); // Adding each item from the list to the queue
        }
    }

    /**
     * Constructor to create a queue with specified initial size.
     *
     * @param size The initial size of the queue.
     */
    public Queue(int size) {
        CircularQArray = (T[]) new Object[size];
    }

    /**
     * Method to check if the queue is full.
     *
     * @return true if the queue is full, false otherwise.
     */
    public boolean isFull() {
        return size == CircularQArray.length;
    }

    /**
     * Method to check if the queue is empty.
     *
     * @return true if the queue is empty, false otherwise.
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Method to add an element to the rear of the queue.
     *
     * @param element The element to be added to the queue.
     */
    public void enqueue(T element) {
        if (isFull()) {
            resize(); // Resizing the queue if it's full
        }
        rear = (rear + 1) % CircularQArray.length; // Updating rear index (increment)
        if (front == -1) {
            front = 0; // If it's the first element, updating front index
        }
        CircularQArray[rear] = element; // Adding the element to the queue
        size++;   // Update the size after adding new element
        System.out.println("Added Element: " + element);
    }

    /**
     * Method to remove and return the element from the front of the queue.
     *
     * @return The removed element from the front of the queue, or null if the queue is empty.
     */
    public T dequeue() {
        if (isEmpty()) {
            System.out.println("CircularQueueArray is Empty!");
            return null;
        }
        T removedElement = CircularQArray[front]; // Storing the element to be removed
        if (front == rear) {
            front = -1; // Resetting front and rear if it's the last element in the queue
            rear = -1;
        } else {
            front = (front + 1) % CircularQArray.length; // Moving front index
        }
        size--;  // Update size after removing element
        System.out.println("Removed element: " + removedElement);
        return removedElement;
    }

    /**
     * Method to get the size of the queue.
     *
     * @return The size of the queue.
     */
    public int getSize() {
        return size;
    }

    /**
     * Method to resize the queue when it's full.
     */
    public void resize() {
        int newSize = CircularQArray.length * 2; // Doubling the size of the array
        T[] newArray = (T[]) new Object[newSize]; // Creating a new array with the new size
        int i = 0;
        // Transferring elements from the old array to the new array
        while (!isEmpty()) {
            newArray[i++] = dequeue();
        }
        front = 0; // Resetting front index
        rear = i - 1; // Setting rear index to the last element in the new array
        CircularQArray = newArray; // Updating the array reference
    }

    /**
     * Method to search for an element in the queue and return its index.
     *
     * @param element The element to search for in the queue.
     * @return The index of the element if found, otherwise -1.
     */
    public int search(T element) {
        if (isEmpty()) {
            System.out.println("QueueArray is Empty!");
            return -1;
        }
        for (int i = front; i != (rear + 1) % CircularQArray.length; i = (i + 1) % CircularQArray.length) {
            if (CircularQArray[i].equals(element)) {
                System.out.println("Element found at index: " + i);
                return i;
            }
        }
        System.out.println("Element not found!");
        return -1;
    }

    /**
     * Method to display all elements in the queue.
     */
    public void displayAllElements() {
        if (isEmpty()) {
            System.out.println("CircularQueueArray is Empty!");
        } else {
            int index = 0;
            for (int i = 0; i < size; i++) {
                index = (front + i) % getCircularQArray().length;
                System.out.println(CircularQArray[index] + " ");
            }
            System.out.println();
        }
    }
}

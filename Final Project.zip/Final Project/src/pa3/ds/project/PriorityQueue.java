package pa3.ds.project;

/**
 * Represents a priority queue implementation, extending the functionality of a Queue.
 * Elements in this queue are ordered based on their natural ordering, or by a Comparator provided at queue construction time.
 *
 * @param <T> The type of elements stored in the priority queue, which must implement the Comparable interface.
 */
public class PriorityQueue<T extends Comparable<T>> extends Queue<T> {

    //Constructor
     
    public PriorityQueue() {
        // Setting the circularQArray with Comparable type
        setCircularQArray((T[]) new Comparable[20]);
        setFront(-1);
        setRear(-1);
    }

    /**
     * Inserts the specified element into this priority queue.
     * This method overrides the enqueue method in the Queue class.
     *
     * @param element The element to be inserted.
     */
    @Override
    public void enqueue(T element) {
        if (element == null) {
            // Handle null elements 
            System.out.println("Cannot enqueue null element.");
            return;
        }

        // Enqueue object at the right index based on its priority
       
        if (isEmpty()) {
            // If the queue is empty, simply add the element at index 0
            getCircularQArray()[0] = element;
            setFront(0);
            setRear(0);
            setSize(1);
            System.out.println("Added Element: " + element);
            return;
        }

        int i = 0;
        int index = 0;
        for (i = 0; i < getSize(); i++) {
            index = (getFront() + i) % getCircularQArray().length;
            if (element.compareTo(getCircularQArray()[index]) > 0) {
                break;
            }
            index++;
        }

        insertAtIndex(element, index);
        System.out.println("Added Element: " + element);
    }

    // Method to insert an element at a specific index in the circular queue array
    private void insertAtIndex(T element, int index) {
        if (isFull()) {
            resize(); // Resize the queue if it's full
        }

        for (int i = getRear(); i >= index; i = (i - 1) % getCircularQArray().length) {
            getCircularQArray()[(i + 1) % getCircularQArray().length] = getCircularQArray()[i];
        }

        // Insert the new element at the specified index
        getCircularQArray()[index] = element;
        setRear(getRear() + 1);
        setSize(getSize() + 1); // Update the size
    }

    /**
     * Displays the element if found in the priority queue.
     *
     * @param element The element to search for in the priority queue.
     */
    public void displayElement(T element) {
        int index = search(element);
        if (index != -1) {
            System.out.println("Element found: " + getCircularQArray()[index]);
        }
    }

    /**
     * Displays all elements with lower priority than the given object.
     *
     * @param element The reference element to compare with.
     */
    public void displayLowerElements(T element) {
        for (int i = getFront(); i != (getRear() + 1) % getCircularQArray().length; i = (i + 1) % getCircularQArray().length) {
            if (getCircularQArray()[i].compareTo(element) < 0) {
                System.out.print(getCircularQArray()[i] + " ");
            }
        }
        System.out.println();
    }

    /**
     * Displays all elements with higher priority than the given object.
     *
     * @param element The reference element to compare with.
     */
    public void displayHigherElements(T element) {
        for (int i = getFront(); i != (getRear() + 1) % getCircularQArray().length; i = (i + 1) % getCircularQArray().length) {
            if (getCircularQArray()[i].compareTo(element) > 0) {
                System.out.print(getCircularQArray()[i] + " ");
            }
        }
        System.out.println();
    }
}

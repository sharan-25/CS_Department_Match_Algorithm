package pa3.ds.project;

public class PriorityQueueLinkedList<T extends Comparable<T>> extends QueueLinkedList<T> {

    // Override the enqueue method to insert elements based on priority
	@Override
	public void enqueue(T element) {
	    // Create a new node with the given element.
	    Node<T> newNode = new Node<>(element);

	    // If the queue is empty or the new element has higher priority (lower value) than the front element,
	    // insert it at the front and update front pointer
	    if (isEmpty() || element.compareTo(front.getData()) >= 0) {
	        newNode.setNext(front);
	        front = newNode;
	    } else {
	        Node<T> current = front;
	        Node<T> previous = null;

	        // Traverse the queue to find the correct position to insert the new element based on its priority
	        while (current != null && element.compareTo(current.getData()) < 0) {
	            previous = current;
	            current = current.getNext();
	        }

	        // Insert the new element after the previous node
	        if (previous != null) {
	            newNode.setNext(previous.getNext());
	            previous.setNext(newNode);
	        } else {
	            newNode.setNext(front);
	            front = newNode;
	        }
	    }

	    // Increment the size of the queue.
	    size++;
	}

	

    // Display the element if found in the priority queue
    public void displayElement(T element) {
        Node<T> current = front;
        while (current != null) {
            if (current.getData().equals(element)) {
                System.out.println("Element found: " + current.getData());
                return;
            }
            current = current.getNext();
        }
        System.out.println("Element not found!");
    }

    // Display all elements with higher priority than the given object
    public void displayHigherElements(T element) {
        Node<T> current = front;
        while (current != null) {
            if (current.getData().compareTo(element) > 0) {
                System.out.print(current.getData() + " ");
            }
            current = current.getNext();
        }
        System.out.println();
    }

    // Display all elements with lower priority than the given object
    public void displayLowerElements(T element) {
        Node<T> current = front;
        while (current != null) {
            if (current.getData().compareTo(element) < 0) {
                System.out.print(current.getData() + " ");
            }
            current = current.getNext();
        }
        System.out.println();
    }
}

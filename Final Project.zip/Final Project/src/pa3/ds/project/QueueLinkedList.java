package pa3.ds.project;

/**
 * Represents a queue implemented using a linked list.
 *
 * @param <T> The type of elements stored in the queue.
 */
public class QueueLinkedList<T> {

    protected Node<T> front;   // Tracks the first element of the queue
    protected Node<T> rear;    // Tracks the last element in the queue
    protected int size;        // Tracks the size of the queue

    /**
     * Constructs an empty queue.
     */
    public QueueLinkedList() {
        this.front = null;
        this.rear = null;
        this.size = 0;  // Initialize size to 0
    }

    /**
     * Checks if the queue is empty.
     *
     * @return true if the queue is empty, false otherwise.
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Inserts an element at the rear of the queue.
     *
     * @param element The element to be inserted.
     */
    public void enqueue(T element) {
        // Creating a new node using Node class and storing data: element
        Node<T> newNode = new Node<T>(element);
        // If queue is empty, set both front and rear to newNode
        if (isEmpty()) {
            front = newNode;
        } else {
            // Otherwise, set the next of rear to newNode
            rear.setNext(newNode);
        }
        // Update rear to newNode and increment size
        rear = newNode;
        size++;
    }

    /**
     * Deletes the element at the front of the queue.
     *
     * @return The element removed from the front of the queue, or null if the queue is empty.
     */
    public T dequeue() {
        if (isEmpty()) {
            System.out.println("Queue is Empty!");
            return null;
        }
        Node<T> removedNode = front;
        // Move front to the next node
        front = front.getNext();
        // If front becomes null(there was only one element), set rear to null as well
        if (front == null) {
            rear = null;
        }
        size--;  // Decrement size
        return removedNode.getData();
    }

    /**
     * Returns the size of the queue.
     *
     * @return The size of the queue.
     */
    public int getSize() {
        return size;
    }

    /**
     * Displays all elements in the queue.
     */
    public void displayAllElements() {
        Node<T> current = front;
        while (current != null) {
            System.out.print(current.getData() + " ");
            current = current.getNext();
        }
        System.out.println();
    }
}

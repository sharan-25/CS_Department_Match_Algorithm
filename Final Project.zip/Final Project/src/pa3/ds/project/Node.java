package pa3.ds.project;

/**
 * Represents a node in a linked list.
 *
 * @param <T> The type of data stored in the node.
 */
public class Node<T> {

    private T data; // The data stored in the node
    private Node<T> next; // Reference to the next node

    /**
     * Constructs a new node with the specified data.
     *
     * @param data The data to be stored in the node.
     */
    public Node(T data) {
        this.data = data;
        this.next = null;
    }

    /**
     * Retrieves the data stored in the node.
     *
     * @return The data stored in the node.
     */
    public T getData() {
        return data;
    }

    /**
     * Sets the data to be stored in the node.
     *
     * @param data The data to be stored in the node.
     */
    public void setData(T data) {
        this.data = data;
    }

    /**
     * Retrieves the reference to the next node.
     *
     * @return The reference to the next node.
     */
    public Node<T> getNext() {
        return next;
    }

    /**
     * Sets the reference to the next node.
     *
     * @param next The reference to the next node.
     */
    public void setNext(Node<T> next) {
        this.next = next;
    }

    /**
     * Returns a string representation of the node.
     *
     * @return A string representation of the node, including its data and reference to the next node.
     */
    @Override
    public String toString() {
        return "Node [data=" + data + ", next=" + next + "]";
    }
}

import pa3.ds.project.*;
import pa3.model.project.Course;
import pa3.model.project.Department;
import pa3.model.project.Professor;
import java.io.FileNotFoundException;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.io.File;

public class Application {

	public static void main(String[] args) {
		
		
        //Reading External Files
       
        
        System.out.println("File Reading...profs.txt.");
        // Create lists to store professors and the priority queue for processing
        List<Professor> listOfProfs = new ArrayList<>();
        PriorityQueue<Professor> profProcessingQueue = new PriorityQueue<>();
       
        // Read professors from profs.txt
        try (Scanner scanner = new Scanner(new File("F:\\SEM-3\\ADVANCE OOPS\\profs.txt"))) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                // Parse line and create Professor objects
               
                String[] parts = line.split(":");
                
                if (parts.length == 5) {
                    int id = Integer.parseInt(parts[0]);
                    String name = parts[1];
                    double seniority = Double.parseDouble(parts[2]);
                    Date hiringDate = (Date) new SimpleDateFormat("dd-MM-yyyy").parse(parts[3]);
                    Set<String> setOfDisciplines = new HashSet<>(Arrays.asList(parts[4].split(",")));
                    Professor professor = new Professor(id, name, seniority, hiringDate);
                    professor.setSetOfDisciplines( setOfDisciplines );
                    
                   // System.out.println(professor);
                    
                    listOfProfs.add(professor); // Adding professor to the list
                    profProcessingQueue.enqueue(professor); // Adding professor to the processing queue
                    
                } else {
                    System.out.println("Invalid line format: " + line);
                }
            }
        } catch (FileNotFoundException | ParseException e) {
            e.printStackTrace();
        }

        System.out.println("File Reading...courses_f22.txt.");
        
       // Create Computer Science Department with the list of professors
        Department csDepartment = new Department(listOfProfs);

        // Read courses from courses_f22.txt
        try (Scanner scanner = new Scanner(new File("F:\\\\SEM-3\\\\ADVANCE OOPS\\\\courses_f22.txt"))) {
            while (scanner.hasNextLine()) {
            	
                String line = scanner.nextLine();
                // Parse line and create Course objects
                // format: courseId, title, discipline, hours, numOfGroups
                String[] parts = line.split(": ");
                if(parts.length==5) {
                
	                String courseId = parts[0].trim();
	                String title = parts[1].trim();
	                String discipline = parts[2].trim();
	                int hours = Integer.parseInt(parts[3].trim());
	                int numOfGroups = Integer.parseInt(parts[4].trim());
	               
	                Course course = new Course(courseId, title, discipline, hours, numOfGroups);
	                //System.out.println(course);
	                csDepartment.addCourse(course); // Add course to the department's course map
                }
                else {
                	System.out.println("Invalid line format: " + line);
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
	
        //Note: csDepartment object contains the CourseMap, And profProcessingQueue contains professors queued up based on their seniority level
        
        // Match courses to professors
    	matchCoursesToProfessors(csDepartment, profProcessingQueue);

    	// Print out affected courses
	    for (Professor professor : listOfProfs) {
	        System.out.println("Professor " + professor.getName() + " is assigned to courses: " + professor.getListOfAffectedCourses());
	    }
	}
    
	//Note: csDepartment object contains the CourseMap, And profProcessingQueue contains professors queued up based on their seniority level
    // So we will retrieve the professor with highest seniority from the front of the queue using dequeue method.
    //Later, read the requested hours, courseId, numOfgroups requested by the professor from the profsId_selection.txt file.
    //Check if the CourseId requested by the professor is exists  in the CourseMap.If it does, retrieve the corresponding Course object.
    //Later check, that course is available (not null) and still has available groups (numOfGroups > 0).
    //Verify if the professor's set of disciplines (setOfDisciplines) contains the discipline of the course they wish to teach.
    //Assign the course to the professor if conditions are met .
    //Update the number of groups for the course, subtracting the number of groups assigned to the professor.
    //Add the assigned course to the professor's listOfAffectedCourses
    //Repeat steps for each course selection made by the professor until their maximum requested hours are reached
    
    //After processing all course selections for the current professor, move on to the next professor in the profProcessingQueue
    //Repeat the steps until all professors in the queue have been processed or until the queue becomes empty.
    
    // Helper method to match courses to professors
    private static void matchCoursesToProfessors(Department department, PriorityQueue<Professor> profQueue) {
        while (!profQueue.isEmpty()) {
            Professor professor = profQueue.dequeue();
            // Read the professor's selection file
            //This concatenates the professor's ID with the string "_selection.txt". This assumes that the course 
            //selection files for each professor follow a naming convention where the professor's ID is combined with "_selection.txt" to
            //form the filename.
            String filePath = "F:\\SEM-3\\ADVANCE OOPS\\"+professor.getId() + "_selection.txt";
            
            //String filePath = "..\\resources\\" + professor.getId() + "_selection.txt";
            System.out.println(filePath);
            try (Scanner scanner = new Scanner(new File(filePath))) {
            	
                int maxRequestedHours = Integer.parseInt(scanner.nextLine().trim()); // Reading the max requested hours
                
                while (scanner.hasNextLine()) {
                    String courseSelection = scanner.nextLine().trim();
                    String[] parts = courseSelection.split(",");
                    if (parts.length == 2) {
                        String courseId = parts[0].trim();       //Reads the courseId
                        
                        int numOfGroupsRequested = Integer.parseInt(parts[1].trim());   //reads the requested number of groups
                        
                         //System.out.println(courseId +" " +numOfGroupsRequested);
                        Course course = department.getCourseMap().get(courseId);
                        
                        if (course != null && course.getNumOfGroups() > 0 && professor.getSetOfDisciplines().contains(course.getDiscipline())) {
                        	
                            
                            int weeklyHours = getWeeklyCourseHours(course.getNumberOfHours());
                            
                            
                            int numGroupsAssigned = Math.min(Math.min((int)(maxRequestedHours / weeklyHours), numOfGroupsRequested), course.getNumOfGroups());


                            if (numGroupsAssigned > 0) {
                                // Assign the course to the professor
                                Course assignedCourse = new Course(course);
                                assignedCourse.setNumOfGroups(numGroupsAssigned);
                                professor.getListOfAffectedCourses().add(assignedCourse);
                                
                                //Total Assigned Hours to Professor
                                int TotalAssignedHours = (numGroupsAssigned * weeklyHours);
                                
                                //Update the maxRequestedHours by subtracting the TotalassignedHours 
                                maxRequestedHours -= TotalAssignedHours;
                                
                                // Update remaining number of groups for the course
                                course.setNumOfGroups(course.getNumOfGroups() - numGroupsAssigned);
                               
                            }
                        }
                    } else {
                        System.out.println("Invalid line format in selection file of Professor " + professor.getId() + ": " + courseSelection);
                    }
                }
            } catch (FileNotFoundException e) {
                System.out.println("Selection file not found for Professor " + professor.getId() + ": " + filePath);
            }
        }
    }

    // Helper method to calculate weekly hours from total hours
    private static int getWeeklyCourseHours(int totalHours) {
        if (totalHours == 45) return 3;
        else if (totalHours == 60) return 4;
        else if (totalHours == 75) return 5;
        else if (totalHours == 90) return 6;
        else return 0; 
    }
}
